var socket = io("http://localhost:7000");
$(document).ready(function(){
	$("#loginForm").show();
	$("#chatForm").hide();
});